import React, { useEffect, useState } from "react";
import ReviewList from "./components/ReviewList";
import SortingOptions from "./components/SortingOptions";
import ReviewForm from "./components/ReviewForm";
import axios from "axios";

const api_end_point = "http://localhost:3001/api"

function App() {
  const [userReviews, setUserReviews] = useState([]);
  const [sortedReviews, setSortedReviews] = useState([...userReviews]); 

  useEffect(() => {
    axios.get(`${api_end_point}/atsiliepimai`)
    .then((result) => {
      setUserReviews(result.data)
    });
  }, [])

  
  const addNewCustomerReview = (customerReview) => {
   
    axios.post(`${api_end_point}/atsiliepimai`, {
      vardas: customerReview.vardas,
      pastas: customerReview.pastas,
      tekstas: customerReview.tekstas,
      vertinimas: customerReview.vertinimas,
      laikas: customerReview.laikas
    })


    setUserReviews([...userReviews, customerReview]);
    setSortedReviews([...sortedReviews, customerReview]);
  };


  const handleSortChange = (sortedReviews) => {
    setSortedReviews([...sortedReviews]);
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>User Reviews</h1>
      </header>
      <main className="app-main">
        <SortingOptions
          userReviews={userReviews}
          onSortChange={handleSortChange}
        /> 
        <ReviewList userReviews={sortedReviews.length > 0 ? sortedReviews : userReviews} />
        <ReviewForm onSubmit={addNewCustomerReview} />
      </main>
    </div>
  );
};

export default App;